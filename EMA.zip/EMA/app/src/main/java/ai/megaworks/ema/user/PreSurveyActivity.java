package ai.megaworks.ema.user;

import android.Manifest;
import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.Window;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.core.app.ActivityCompat;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.messaging.FirebaseMessaging;

import ai.megaworks.ema.Global;
import ai.megaworks.ema.LoginActivity;
import ai.megaworks.ema.R;
import ai.megaworks.ema.api.FirebaseTokenInfo;
import ai.megaworks.ema.api.LoginResponse;
import ai.megaworks.ema.api.MindcareApi;
import ai.megaworks.ema.api.RetrofitClient;
import ai.megaworks.ema.api.SurveySubjectRequest;
import ai.megaworks.ema.api.SurveySubjectResponse;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class PreSurveyActivity extends AppCompatActivity {

    private AppCompatButton btnNext;

    private LinearLayout logout;

    private TextView user_name;
    private ImageView user_btn;


    RetrofitClient retrofitClient = RetrofitClient.getInstance();

    MindcareApi mindcareApi = RetrofitClient.getRetrofitInterface();

    static final int PERMISSIONS_REQUEST = 0x0000001;

    public void OnCheckPermission() {

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED
                || ActivityCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.RECORD_AUDIO)) {
                Toast.makeText(this, "앱 실행을 위해서는 권한을 설정해야 합니다", Toast.LENGTH_LONG).show();
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.RECORD_AUDIO, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE},
                        PERMISSIONS_REQUEST);
            } else {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.RECORD_AUDIO, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE},
                        PERMISSIONS_REQUEST);
            }
        }
    }


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pre_survey);

        OnCheckPermission();

        user_btn = findViewById(R.id.user_btn);
        user_name = findViewById(R.id.user_name);
        logout = findViewById(R.id.logout);

        btnNext = findViewById(R.id.btnNext);
        btnNext.setOnClickListener(view -> {
            savePreSurvey();
        });

        // 마이페이지
        user_btn.setOnClickListener(view -> {
            Intent intent = new Intent(getApplicationContext(), MyPageActivity.class);
            startActivity(intent);
        });

        logout.setOnClickListener(view -> {
            Dialog dialog = new Dialog(view.getContext());
            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
            dialog.setContentView(R.layout.dialog_logout);
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            dialog.setCanceledOnTouchOutside(false);
            dialog.show();

            dialog.findViewById(R.id.ok).setOnClickListener(v -> {
                SharedPreferences sharedPreferences2 = getSharedPreferences("TOKEN", MODE_PRIVATE);
                SharedPreferences.Editor editor2 = sharedPreferences2.edit();
                editor2.putString("Token", null);
                editor2.commit();
                Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                startActivity(intent);
                dialog.dismiss();
            });
            dialog.findViewById(R.id.cancel).setOnClickListener(v -> {
                dialog.dismiss();
            });
        });

        FirebaseMessaging.getInstance().getToken().addOnCompleteListener(new OnCompleteListener<String>() {
            @Override
            public void onComplete(@NonNull Task<String> task) {
                if (!task.isSuccessful()) {
                    Log.d("FCM_Fail", task.getException() + "");
                    return;
                }
                String FCM_Token = task.getResult();
                Log.d("FCM_TOKEN", FCM_Token);
                setFCMToken(Global.TOKEN.getId(), FCM_Token);
                SharedPreferences sharedPreferences2 = getSharedPreferences("TOKEN", MODE_PRIVATE);
                SharedPreferences.Editor editor2 = sharedPreferences2.edit();
                editor2.putString("Token", FCM_Token);
                editor2.commit();


            }
        });


        // 이전에 초기 설문 조사를 실시한 이력이 있는지 확인
        mindcareApi.checkValidSubject(new SurveySubjectRequest(1L, Global.TOKEN.getId())).enqueue(new Callback<SurveySubjectResponse>() {
            @Override
            public void onResponse(Call<SurveySubjectResponse> call, Response<SurveySubjectResponse> response) {
                if (response.isSuccessful()) {
                    SurveySubjectResponse result = response.body();
                    Global.TOKEN.setSurveySubjectId(result.getId());
                    if (result.isFinishedPreSurvey()) {
                        moveToMain();
                    }
                }
            }

            @Override
            public void onFailure(Call<SurveySubjectResponse> call, Throwable t) {
                Log.d(this.getClass().getName() + "fail", t.getMessage() + "");
                Toast.makeText(PreSurveyActivity.this, "인터넷 연결을 확인해주세요.222222", Toast.LENGTH_SHORT).show();
            }
        });

    }

    public void setFCMToken(Long id, String token) {
        retrofitClient = RetrofitClient.getInstance();
        mindcareApi = RetrofitClient.getRetrofitInterface();

        FirebaseTokenInfo firebaseTokenInfo = new FirebaseTokenInfo(id, token);
        mindcareApi.setFCMtoken(firebaseTokenInfo).enqueue(new Callback<Boolean>() {
            @Override
            public void onResponse(Call<Boolean> call, Response<Boolean> response) {
                if (response.isSuccessful()) {
                    Log.d("SET_FCM", response.body().toString());
                }
            }

            @Override
            public void onFailure(Call<Boolean> call, Throwable t) {

            }
        });
    }


    public void savePreSurvey() {
        //TODO : SurveySubjectRequest 프로퍼티 값 고정 해지
        mindcareApi.togglePreSurveyStatus(new SurveySubjectRequest(Global.TOKEN.getSurveySubjectId())).enqueue(new Callback<Void>() {

            @Override
            public void onResponse(Call<Void> call, Response<Void> response) {
                if (response.isSuccessful()) {
                    moveToMain();
                }
            }

            @Override
            public void onFailure(Call<Void> call, Throwable t) {
                Toast.makeText(getApplicationContext(), "서버와 연결이 불안정합니다. 다시 시도해주세요.", Toast.LENGTH_SHORT).show();

            }
        });
    }

    public void moveToMain() {
        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
        startActivity(intent);
    }
}
