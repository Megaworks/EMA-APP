package ai.megaworks.ema.api;

import java.time.LocalDate;

public class SurveySubjectResponse {
    private Long id;

    private Long subjectId;

    private Long surveyId;

    private String startAt;

    private String endAt;

    private boolean finishedPreSurvey;

    private boolean finishedPostSurvey;

    public SurveySubjectResponse(Long id, Long subjectId, Long surveyId, String startAt, String endAt, boolean finishedPreSurvey, boolean finishedPostSurvey) {
        this.id = id;
        this.subjectId = subjectId;
        this.surveyId = surveyId;
        this.startAt = startAt;
        this.endAt = endAt;
        this.finishedPreSurvey = finishedPreSurvey;
        this.finishedPostSurvey = finishedPostSurvey;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getSubjectId() {
        return subjectId;
    }

    public void setSubjectId(Long subjectId) {
        this.subjectId = subjectId;
    }

    public Long getSurveyId() {
        return surveyId;
    }

    public void setSurveyId(Long surveyId) {
        this.surveyId = surveyId;
    }

    public String getStartAt() {
        return startAt;
    }

    public void setStartAt(String startAt) {
        this.startAt = startAt;
    }

    public String getEndAt() {
        return endAt;
    }

    public void setEndAt(String endAt) {
        this.endAt = endAt;
    }

    public boolean isFinishedPreSurvey() {
        return finishedPreSurvey;
    }

    public void setFinishedPreSurvey(boolean finishedPreSurvey) {
        this.finishedPreSurvey = finishedPreSurvey;
    }

    public boolean isFinishedPostSurvey() {
        return finishedPostSurvey;
    }

    public void setFinishedPostSurvey(boolean finishedPostSurvey) {
        this.finishedPostSurvey = finishedPostSurvey;
    }
}
