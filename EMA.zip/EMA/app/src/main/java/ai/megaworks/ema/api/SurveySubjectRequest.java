package ai.megaworks.ema.api;

public class SurveySubjectRequest {

    private Long id;

    private Long surveySubjectId;

    private Long surveyId;

    private Long subjectId;

    public SurveySubjectRequest(Long id) {
        this.id = id;
    }

    public SurveySubjectRequest(Long surveyId, Long subjectId) {
        this.surveyId = surveyId;
        this.subjectId = subjectId;
    }

}
