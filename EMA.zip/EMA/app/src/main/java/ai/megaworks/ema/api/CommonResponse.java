package ai.megaworks.ema.api;

import com.google.gson.annotations.SerializedName;

public class CommonResponse<T> {

    @SerializedName("status")
    private Status status;


}
